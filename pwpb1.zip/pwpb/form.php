<html>
<head>
<title>FORM</title>
</head>
<body> 
	<h3>Biodata Siswa</h3>
 <?php
 extract($_POST);
 echo 'Nama Lengkap : '.$nl.' </br>';
 echo "Nama Panggilan : ".$np." </br>";
 echo 'Jenis Kelamin : '.$jk.' </br>';
 echo 'NISN : '.$nisn.' </br>';
 echo 'NIK : '.$nik.' </br>';
 echo 'Tempat dan Tanggal Lahir : '.$ttl.' </br>';
 echo 'Asal Sekolah : '.$as.' </br>';
 echo 'No SKHU : '.$skhu.' </br>';
 echo 'Tanggal diterima diSekolah ini : '.$td.' </br>';
 echo 'Alasan pindah ke Sekolah ini : '.$ap.' </br>';
 echo 'Agama: '.$agama.' </br>';
 echo 'Alamat : '.$alamat.' </br>';
 echo 'Tinggal Bersama : '.$tb.' </br>';
 echo 'Mode Transportasi : '.$transportasi.' </br>';
 echo 'Handphone : '.$nohp.' </br>';
 echo 'NO KPS : '.$nokps.' </br>';
 ?>
 	<h3>Biodata Ayah</h3>
 <?php
 	echo 'Nama : '.$nama.' </br>';
 	echo 'Tahun Lahir : '.$tl.' </br>';
 	echo 'Pendidikan : '.$pendidikan.' </br>';
 	echo 'Pekerjaan : '.$pekerjaan.' </br>';
 	echo 'Penghasilan : '.$penghasilan.' </br>';
 ?>
 	<h3>Biodata Ibu</h3>
 <?php
 	echo 'Nama : '.$nama2.' </br>';
 	echo 'Tahun Lahir : '.$tl2.' </br>';
 	echo 'Pendidikan : '.$pendidikan2.' </br>';
 	echo 'Pekerjaan : '.$pekerjaan2.' </br>';
 	echo 'Penghasilan : '.$penghasilan2.' </br>';
 ?>
 <form action ="tugas3.php">
  <input type ="submit" value ="kembali" name ="Kembali">
 </form>
</body>
</html>