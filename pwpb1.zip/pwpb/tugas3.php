<!DOCTYPE html>
<html>
<head>
	<title>FORMULIR</title>
</head>
<style>
body{
	background-image: url(aku.jpg);
	font-family: sans-serif;
	border: 10px double #5f9ea0;
}
button{
	background-color: blue;
}
table{
	border: 10px double #a9a9a9;
}

table tr td{
	border: double #a9a9a9;
}
input{

}
</style>
<body>
	<h2 align="center">DATA IDENTITAS PESERTA DIDIK BARU<p>TAHUN AJARAN 2019/2020</p></h2>
	<form action="form.php" method="post">
		<table width="745" border="1px" cellspacing="0" cellpadding="5" align="center" bgcolor="white">
			<tr align="center" bgcolor="white">
				<td width="174"><b>DATA DIRI</b></td>
				<td width="5"></td>
				<td width="353"><b>KETERANGAN</b></td>
			</tr>
			<tr>
				<td>Nama Lengkap</td>
				<td>:</td>
				<td><input type="text" name="nl" size="25"></td>
			</tr>

			<tr>
				<td>Nama Panggilan</td>
				<td>:</td>
				<td><input type="text" name="np" size="25"></td>
			</tr>

			<tr>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td><input type="radio" name="jk" value="laki-laki">Laki-Laki<input type="radio" name="jk" value="perempuan">Perempuan</td>
			</tr>

			<tr>
				<td>NISN</td>
				<td>:</td>
				<td><input type="number" name="nisn" size="25"></td>
			</tr>

			<tr>
				<td>NIK</td>
				<td>:</td>
				<td><input type="number" name="nik" size="25"></td>
			</tr>


			<tr>
				<td>Tempat dan Tanggal Lahir</td>
				<td>:</td>
				<td><input type="text" name="ttl" size="25">
					<input type="date" name="td" size="25"></td>
			</tr>

			<tr>
				<td>Asal Sekolah</td>
				<td>:</td>
				<td><input type="text" name="as" size="25"></td>
			</tr>

			<tr>
				<td>Nomor SKHU</td>
				<td>:</td>
				<td><input type="number" name="skhu" size="25"></td>
			</tr>

			<tr>
				<td>Tanggal diterima diSekolah ini</td>
				<td>:</td>
				<td><input type="date" name="td" size="25"></td>
			</tr>

			<tr>
				<td>Alasan Pindah KeSekolah ini</td>
				<td>:</td>
				<td><input type="text" name="ap" size=""></td>
			</tr>

			<tr>
				<td>Agama</td>
				<td>:</td>
				<td><select name="agama" id="agama">
					<option>Islam</option>
					<option>Budha</option>
					<option>Kristen</option>
					<option>Konghucu</option>
					<option>Hindu</option>
				</select></td>
			</tr>

			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td><input type="text" name="alamat" size="25"></td>
			</tr>

			<tr>
				<td>Tinggal Bersama</td>
				<td>:</td>
				<td><select name="tb" id="id">
					<option>Orang Tua</option>
					<option>Teman</option>
					<option>Saudara</option>
					<option>Kakek</option>
					<option>Nenek</option>
				</select></td>
			</tr>

			<tr>
				<td>Metode Transportasi</td>
				<td>:</td>
				<td>
					<input type="radio" name="transportasi" value="kendaraan pribadi">Kendaraan Pribadi
					<input type="radio" name="transportasi" value="kendaraan umum">Kendaraan Umum
					<br>
					<input type="radio" name="transportasi" value="jalan kaki">Jalan Kaki
					<input type="radio" name="transportasi" value="lainnya">Lainnya
				</td>
			</tr>

			<tr>
				<td>HandPhone</td>
				<td>:</td>
				<td><input type="text" name="nohp" size="25"></td>
			</tr>

			<tr>
				<td>No KPS (Kartu Perlindungan Sosial)</td>
				<td>:</td>
				<td><input type="number" name="nokps" size="25"></td>
			</tr>

			<tr>
				<th>Data Ayah Kandung</th>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><input type="text" name="nama" size="25"></td>
			</tr>
			<tr>
				<td>Tahun Lahir</td>
				<td>:</td>
				<td><input type="text" name="tahun lahir" size="25"></td>
			</tr>
			<tr>
				<td>Pendidikan</td>
				<td>:</td>
				<td><input type="text" name="pendidikan" size="25"></td>
			</tr>
			<tr>
				<td>Pekerjaan</td>
				<td>:</td>
				<td><input type="text" name="pekerjaan" size="25"></td>
			</tr>
			<tr>
				<td>Penghasilan Perbulan</td>
				<td>:</td>
				<td>
					<input type="radio" name="penghasilan" value="< 500.000">< 500.000
					<input type="radio" name="penghasilan" value="1 jt">1 - 2 Juta
					<br>
					<input type="radio" name="penghasilan" value="3 jt">3 - 4 Juta
					<input type="radio" name="penghasilan" value="5 jt">> 5 Juta
				</td>
			</tr>

			<tr>
				<th>Data Ibu Kandung</th>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><input type="text" name="nama2" size="25"></td>
			</tr>
			<tr>
				<td>Tahun Lahir</td>
				<td>:</td>
				<td><input type="date" name="tl2" size="25"></td>
			</tr>
			<tr>
				<td>Pendidikan</td>
				<td>:</td>
				<td><input type="text" name="pendidikan2" size="25"></td>
			</tr>
			<tr>
				<td>Pekerjaan</td>
				<td>:</td>
				<td><input type="text" name="pekerjaan2" size="25"></td>
			</tr>
			<tr>
				<td>Penghasilan Perbulan</td>
				<td>:</td>
				<td>
					<input type="radio" name="penghasilan2" value="< 500.000">< 500.000
					<input type="radio" name="penghasilan2" value="1 jt">1 - 2 Juta
					<br>
					<input type="radio" name="penghasilan2" value="3 jt">3 - 4 Juta
					<input type="radio" name="penghasilan2" value="5 jt">> 5 Juta
				</td>
			</tr>
		</table>
		<center><input type="reset" value="clear" name="clear"></center>
		<center><input type ="submit" value="kirim" name="kirim"></center>
	</form>
</body>
</html>
















